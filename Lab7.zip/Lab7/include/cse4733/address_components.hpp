#ifndef ADDRESS_COMPONENTS_HPP
#define ADDRESS_COMPONENTS_HPP

namespace cse4733
{

    struct address_components
    {
        unsigned int vpn;
        unsigned int offset;
    };

} // namespace cse4733

#endif // ADDRESS_COMPONENTS_HPP