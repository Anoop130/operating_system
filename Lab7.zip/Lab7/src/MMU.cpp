#include <cse4733/MMU.hpp>

#include <algorithm>
#include <iostream>
#include <stdexcept>

namespace cse4733 {

MMU::MMU(unsigned int base_address)
    : tlbHits{0}, tlbMisses{0}, m_base_address(base_address) {}

auto MMU::extract_address_components(unsigned int virtual_address)
    -> address_components {
  // Extract VPN and offset from the virtual address.
  address_components components{0, 0};
  components.vpn =
      virtual_address >> MMU::OFFSET_BITS; // Remove the lower 12 bits.
  components.offset =
      virtual_address & MMU::OFFSET_MASK; // Lower 12 bits represent the offset.
  return components;
}

auto MMU::addEntry(unsigned int virtualAddress) -> unsigned int {
  // PSEUDOCODE (English):
  // 1. Extract the virtual page number (VPN) and the page offset from the
  //    provided virtual address.
  // 2. Compute the physical frame base by adding the MMU's base physical
  //    address to the VPN multiplied by the page size.
  // 3. Ensure the page table can store an entry for this VPN; if it cannot,
  //    grow the page table to accommodate the VPN.
  // 4. Record the mapping from VPN to the computed physical frame base in
  //    the page table.
  // 5. Update the TLB by adding the mapping for the VPN to the physical
  //    frame base so future translations can be served from the TLB.
  // 6. Return the final physical address formed by adding the page offset
  //    to the physical frame base.
  return 0;
}

auto MMU::translateAddress(unsigned int virtualAddress) -> unsigned int {
  // PSEUDOCODE (English):
  // 1. Extract the virtual page number (VPN) and the page offset from the
  //    given virtual address.
  // 2. Query the TLB for a mapping for this VPN.
  //    - If the TLB contains a mapping (a TLB hit):
  //        * Increment the TLB hit counter.
  //        * Form the physical address by combining the physical frame base
  //          from the TLB with the page offset, and return it.
  //    - If the TLB does not contain a mapping (a TLB miss):
  //        * Increment the TLB miss counter.
  //        * Create the mapping by invoking addEntry (which updates the
  //          page table and installs the entry into the TLB).
  //        * Return the physical address produced by the newly created
  //          mapping.
  return 0;
}

auto MMU::getHitRatio() const -> double {
  // PSEUDOCODE (English):
  // 1. If the total number of TLB accesses (hits + misses) is zero, return
  //    0.0 to avoid division by zero.
  // 2. Otherwise, return the number of TLB hits divided by the total
  //    number of TLB accesses (hits plus misses).
  return 0.0;
}

auto MMU::getMissRatio() const -> double {
  // PSEUDOCODE (English):
  // 1. If the total number of TLB accesses (hits + misses) is zero, return
  //    0.0 to avoid division by zero.
  // 2. Otherwise, return the number of TLB misses divided by the total
  //    number of TLB accesses (hits plus misses).
  return 0.0;
}

} // namespace cse4733
