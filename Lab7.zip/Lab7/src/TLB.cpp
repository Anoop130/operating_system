#include <algorithm>
#include <iostream>
#include <optional>

#include <cse4733/TLB.hpp>

void cse4733::TLB::addEntry(unsigned int virtual_page_number,
                            unsigned int physical_frame_number) {
  // PSEUDOCODE:
  // 1. If the virtual page number (VPN) is already present in the TLB:
  //    a. Replace the existing mapping for that VPN with the given physical
  //    frame number. b. Remove that VPN from the eviction-order list wherever
  //    it appears. c. Append that VPN to the end of the eviction-order list to
  //    mark it as most-recently used. d. Log or print that the TLB entry was
  //    updated. e. Return from the function.
  // 2. If the VPN is not present in the TLB:
  //    a. If the number of entries in the TLB is greater than or equal to
  //    MAX_ENTRIES:
  //         i. Let a variable named "oldest" represent the VPN at the front of
  //         the eviction-order list.
  //        ii. Remove the front element from the eviction-order list.
  //       iii. Remove the mapping for the VPN stored in "oldest" from the TLB
  //       entries.
  //        iv. Log or print which VPN was evicted.
  //    b. Create a new mapping from the VPN to the provided physical frame
  //    number in the TLB entries. c. Append the VPN to the end of the
  //    eviction-order list to mark it as most-recently used.
}

auto cse4733::TLB::searchTLB(unsigned int virtualAddress)
    -> std::optional<unsigned int> {
  // PSEUDOCODE:
  // 1. Initialize an empty result (no value).
  // 2. If the virtual address exists as a key in the TLB entries:
  //      set the result to the corresponding physical frame number.
  // 3. Return the result (either contains a physical frame number or remains
  // empty).
  return std::nullopt;
}
